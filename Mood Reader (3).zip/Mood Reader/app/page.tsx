import MoodReader from '@/components/mood-reader'

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <MoodReader />
    </main>
  )
}