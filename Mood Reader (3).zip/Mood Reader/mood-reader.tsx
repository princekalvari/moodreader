'use client'

import { useState, useEffect } from 'react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Star, ThumbsUp, Calendar } from "lucide-react"
import { Input } from "@/components/ui/input"

const emotions = [
  'Happy', 'Sad', 'Anxious', 'Inspired', 'Angry', 'Calm', 'Excited', 'Frustrated',
  'Nostalgic', 'Curious', 'Overwhelmed', 'Hopeful', 'Bored', 'Confident', 'Confused',
  'Grateful', 'Lonely', 'Motivated', 'Relaxed', 'Stressed'
]

const books = {
  Happy: [
    { id: 1, title: "The Hitchhiker's Guide to the Galaxy", author: "Douglas Adams", description: "A comedic science fiction series that's sure to lift your spirits.", rating: 4.5 },
    { id: 2, title: "Good Omens", author: "Terry Pratchett & Neil Gaiman", description: "A hilarious take on the Apocalypse that will leave you in stitches.", rating: 4.3 },
    { id: 3, title: "The Rosie Project", author: "Graeme Simsion", description: "A charming and hilarious journey of love and self-discovery.", rating: 4.0 },
    { id: 4, title: "Bridget Jones's Diary", author: "Helen Fielding", description: "A witty and relatable story of a woman navigating life and love.", rating: 4.1 },
    { id: 5, title: "The Princess Bride", author: "William Goldman", description: "A fantastical adventure filled with humor, romance, and unforgettable characters.", rating: 4.7 },
    { id: 6, title: "The Martian", author: "Andy Weir", description: "A hilarious and thrilling tale of survival on Mars.", rating: 4.6 },
    { id: 7, title: "Where'd You Go, Bernadette", author: "Maria Semple", description: "A quirky and uplifting story about a mother-daughter relationship.", rating: 4.0 },
    { id: 8, title: "The Guernsey Literary and Potato Peel Pie Society", author: "Mary Ann Shaffer", description: "A charming historical novel filled with humor and warmth.", rating: 4.4 },
  ],
  Sad: [
    { id: 6, title: "The Fault in Our Stars", author: "John Green", description: "A touching story about love and loss that resonates with melancholy.", rating: 4.2 },
    { id: 7, title: "A Little Life", author: "Hanya Yanagihara", description: "An emotional journey through friendship and trauma.", rating: 4.1 },
    { id: 8, title: "The Road", author: "Cormac McCarthy", description: "A post-apocalyptic tale of a father and son's journey through a desolate America.", rating: 4.3 },
    { id: 9, title: "Never Let Me Go", author: "Kazuo Ishiguro", description: "A haunting and melancholic exploration of what it means to be human.", rating: 4.0 },
    { id: 10, title: "The Book Thief", author: "Markus Zusak", description: "A poignant story set in Nazi Germany, narrated by Death itself.", rating: 4.6 },
    { id: 11, title: "One Day", author: "David Nicholls", description: "A bittersweet love story spanning two decades.", rating: 3.9 },
    { id: 12, title: "The Kite Runner", author: "Khaled Hosseini", description: "A powerful tale of friendship, betrayal, and redemption.", rating: 4.3 },
    { id: 13, title: "The Lovely Bones", author: "Alice Sebold", description: "A haunting story of loss and healing told from the afterlife.", rating: 3.8 },
  ],
  Anxious: [
    { id: 11, title: "The Anxiety Toolkit", author: "Alice Boyes", description: "Practical strategies for managing anxiety and worry.", rating: 4.0 },
    { id: 12, title: "Hope and Help for Your Nerves", author: "Claire Weekes", description: "A classic self-help book for understanding and overcoming anxiety.", rating: 4.4 },
    { id: 13, title: "First, We Make the Beast Beautiful", author: "Sarah Wilson", description: "A new story about anxiety that's part memoir, part self-help guide.", rating: 4.2 },
    { id: 14, title: "The Worry Trick", author: "David A. Carbonell", description: "How your brain tricks you into expecting the worst and what you can do about it.", rating: 4.3 },
    { id: 15, title: "Dare", author: "Barry McDonagh", description: "A new way to end anxiety and stop panic attacks fast.", rating: 4.5 },
    { id: 16, title: "The Happiness Trap", author: "Russ Harris", description: "A guide to reducing stress and overcoming anxiety using ACT.", rating: 4.3 },
    { id: 17, title: "The Highly Sensitive Person", author: "Elaine N. Aron", description: "How to thrive when the world overwhelms you.", rating: 4.1 },
    { id: 18, title: "Quiet: The Power of Introverts in a World That Can't Stop Talking", author: "Susan Cain", description: "Exploring the strengths of introverts in a noisy world.", rating: 4.5 },
  ],
  Inspired: [
    { id: 16, title: "The Alchemist", author: "Paulo Coelho", description: "A philosophical novel about following your dreams.", rating: 4.6 },
    { id: 17, title: "Atomic Habits", author: "James Clear", description: "A guide to building good habits and breaking bad ones.", rating: 4.8 },
    { id: 18, title: "Big Magic", author: "Elizabeth Gilbert", description: "Creative living beyond fear and embracing curiosity.", rating: 4.4 },
    { id: 19, title: "The Artist's Way", author: "Julia Cameron", description: "A course in discovering and recovering your creative self.", rating: 4.5 },
    { id: 20, title: "Daring Greatly", author: "Brené Brown", description: "How the courage to be vulnerable transforms the way we live, love, parent, and lead.", rating: 4.7 },
    { id: 21, title: "The War of Art", author: "Steven Pressfield", description: "Break through blocks and win your inner creative battles.", rating: 4.3 },
    { id: 22, title: "Grit: The Power of Passion and Perseverance", author: "Angela Duckworth", description: "Why passion and persistence are more important than talent.", rating: 4.5 },
    { id: 23, title: "The Last Lecture", author: "Randy Pausch", description: "A professor's final lecture on achieving your childhood dreams.", rating: 4.6 },
  ],
  Angry: [
    { id: 21, title: "The Subtle Art of Not Giving a F*ck", author: "Mark Manson", description: "A counterintuitive approach to living a good life.", rating: 4.2 },
    { id: 22, title: "Rage Becomes Her", author: "Soraya Chemaly", description: "An exploration of the power of female anger.", rating: 4.5 },
    { id: 23, title: "The Dance of Anger", author: "Harriet Lerner", description: "A woman's guide to changing the patterns of intimate relationships.", rating: 4.3 },
    { id: 24, title: "Anger: Wisdom for Cooling the Flames", author: "Thich Nhat Hanh", description: "Buddhist wisdom for transforming anger into peace and healing.", rating: 4.6 },
    { id: 25, title: "The Cow in the Parking Lot", author: "Leonard Scheff & Susan Edmiston", description: "A Zen approach to overcoming anger.", rating: 4.1 },
    { id: 26, title: "The Upside of Your Dark Side", author: "Todd Kashdan & Robert Biswas-Diener", description: "Why being your whole self - not just your 'good' self - drives success and fulfillment.", rating: 4.2 },
    { id: 27, title: "The Gift of Anger", author: "Arun Gandhi", description: "And other lessons from my grandfather Mahatma Gandhi.", rating: 4.4 },
    { id: 28, title: "Anger Management Workbook for Men", author: "Aaron Karmin", description: "Take control of your anger and master your emotions.", rating: 4.3 },
  ],
}

// Add placeholder books for emotions without specific recommendations
emotions.forEach(emotion => {
  if (!books[emotion]) {
    books[emotion] = [
      { id: 1000 + emotions.indexOf(emotion) * 5, title: "Embracing " + emotion, author: "Jane Doe", description: "A comprehensive guide to understanding and navigating " + emotion.toLowerCase() + " emotions.", rating: 4.2 },
      { id: 1001 + emotions.indexOf(emotion) * 5, title: "The " + emotion + " Chronicles", author: "John Smith", description: "An engaging novel that captures the essence of feeling " + emotion.toLowerCase() + ".", rating: 4.0 },
      { id: 1002 + emotions.indexOf(emotion) * 5, title: emotion + " Mindset", author: "Alex Johnson", description: "Practical strategies for harnessing the power of " + emotion.toLowerCase() + " emotions.", rating: 4.3 },
      { id: 1003 + emotions.indexOf(emotion) * 5, title: "The Art of Being " + emotion, author: "Sam Brown", description: "A philosophical exploration of " + emotion.toLowerCase() + " and its role in our lives.", rating: 4.1 },
      { id: 1004 + emotions.indexOf(emotion) * 5, title: emotion + " in the Modern World", author: "Taylor Green", description: "An insightful analysis of how " + emotion.toLowerCase() + " shapes our society and personal experiences.", rating: 4.4 },
    ]
  }
})

const movies = {
  Happy: [
    { id: 1, title: "The Grand Budapest Hotel", director: "Wes Anderson", description: "A whimsical comedy about the adventures of a legendary concierge and his young protégé.", rating: 4.2 },
    { id: 2, title: "Singin' in the Rain", director: "Stanley Donen, Gene Kelly", description: "A classic musical comedy set in Hollywood during the transition from silent films to talkies.", rating: 4.8 },
    { id: 3, title: "Amélie", director: "Jean-Pierre Jeunet", description: "A charming French comedy about a shy waitress who decides to change the lives of those around her for the better.", rating: 4.4 },
    { id: 4, title: "The Intouchables", director: "Olivier Nakache, Éric Toledano", description: "An uplifting comedy-drama about the unlikely friendship between a wealthy quadriplegic and his caregiver.", rating: 4.5 },
    { id: 5, title: "Little Miss Sunshine", director: "Jonathan Dayton, Valerie Faris", description: "A heartwarming comedy about a dysfunctional family's road trip to a children's beauty pageant.", rating: 4.3 },
  ],
  Sad: [
    { id: 6, title: "The Shawshank Redemption", director: "Frank Darabont", description: "A powerful drama about hope, friendship, and perseverance in the face of injustice.", rating: 4.9 },
    { id: 7, title: "Schindler's List", director: "Steven Spielberg", description: "A haunting historical drama about a German businessman who saved the lives of more than a thousand Jewish refugees during the Holocaust.", rating: 4.9 },
    { id: 8, title: "Life is Beautiful", director: "Roberto Benigni", description: "A heartbreaking yet uplifting story of a father's love for his son during the horrors of the Holocaust.", rating: 4.6 },
    { id: 9, title: "The Green Mile", director: "Frank Darabont", description: "A moving supernatural drama set on death row in a Southern prison.", rating: 4.6 },
    { id: 10, title: "Grave of the Fireflies", director: "Isao Takahata", description: "A devastating animated film about two siblings struggling to survive in Japan during World War II.", rating: 4.7 },
  ],
  Anxious: [
    { id: 11, title: "Inside Out", director: "Pete Docter", description: "An animated exploration of the emotions inside a young girl's mind as she copes with moving to a new city.", rating: 4.7 },
    { id: 12, title: "The Secret Life of Walter Mitty", director: "Ben Stiller", description: "An uplifting adventure about a daydreamer who embarks on a global journey to find himself.", rating: 4.3 },
    { id: 13, title: "Good Will Hunting", director: "Gus Van Sant", description: "A touching drama about a troubled genius finding his place in the world with the help of a therapist.", rating: 4.8 },
    { id: 14, title: "Cast Away", director: "Robert Zemeckis", description: "A survival drama about a FedEx employee stranded on an uninhabited island, learning to cope with isolation and adversity.", rating: 4.4 },
    { id: 15, title: "A Beautiful Mind", director: "Ron Howard", description: "A biographical drama about the life of John Nash, a brilliant mathematician struggling with mental illness.", rating: 4.5 },
  ],
  Inspired: [
    { id: 16, title: "The Pursuit of Happyness", director: "Gabriele Muccino", description: "An inspiring true story of a struggling salesman's journey to build a better life for his son.", rating: 4.7 },
    { id: 17, title: "Dead Poets Society", director: "Peter Weir", description: "A powerful drama about an English teacher who inspires his students through poetry.", rating: 4.8 },
    { id: 18, title: "The Theory of Everything", director: "James Marsh", description: "A biographical drama about the life of physicist Stephen Hawking and his relationship with his wife.", rating: 4.4 },
    { id: 19, title: "Hidden Figures", director: "Theodore Melfi", description: "The true story of African American women mathematicians who played a vital role in NASA during the early years of the US space program.", rating: 4.6 },
    { id: 20, title: "Whiplash", director: "Damien Chazelle", description: "An intense drama about a young jazz drummer pushing himself to the limits to achieve greatness.", rating: 4.7 },
  ],
  Angry: [
    { id: 21, title: "12 Angry Men", director: "Sidney Lumet", description: "A tense courtroom drama where one juror tries to prevent a miscarriage of justice.", rating: 4.9 },
    { id: 22, title: "Network", director: "Sidney Lumet", description: "A satirical look at the world of television news and the power of media.", rating: 4.5 },
    { id: 23, title: "Falling Down", director: "Joel Schumacher", description: "A controversial drama about an ordinary man's violent breakdown in response to societal pressures.", rating: 4.2 },
    { id: 24, title: "The Social Network", director: "David Fincher", description: "A drama about the founding of Facebook and the conflicts that arose from its success.", rating: 4.5 },
    { id: 25, title: "Three Billboards Outside Ebbing, Missouri", director: "Martin McDonagh", description: "A dark comedy-drama about a mother's quest for justice for her murdered daughter.", rating: 4.4 },
  ],
}

// Add placeholder movies for emotions without specific recommendations
emotions.forEach(emotion => {
  if (!movies[emotion]) {
    movies[emotion] = [
      { id: 2000 + emotions.indexOf(emotion) * 5, title: "The " + emotion + " Experience", director: "Jane Doe", description: "A thought-provoking film exploring the depths of " + emotion.toLowerCase() + " emotions.", rating: 4.2 },
      { id: 2001 + emotions.indexOf(emotion) * 5, title: emotion + " in Motion", director: "John Smith", description: "A visually stunning journey through the landscape of " + emotion.toLowerCase() + " feelings.", rating: 4.0 },
      { id: 2002 + emotions.indexOf(emotion) * 5, title: "The Art of Being " + emotion, director: "Alex Johnson", description: "A documentary-style film showcasing real-life stories of people experiencing " + emotion.toLowerCase() + ".", rating: 4.3 },
      { id: 2003 + emotions.indexOf(emotion) * 5, title: emotion + " Unveiled", director: "Sam Brown", description: "An intimate portrayal of characters navigating through " + emotion.toLowerCase() + " moments in life.", rating: 4.1 },
      { id: 2004 + emotions.indexOf(emotion) * 5, title: "Echoes of " + emotion, director: "Taylor Green", description: "A poetic narrative exploring the ripple effects of " + emotion.toLowerCase() + " across different lives.", rating: 4.4 },
    ]
  }
})

function playTypingSound() {
  const audioContext = new (window.AudioContext || window.webkitAudioContext)();
  const oscillator = audioContext.createOscillator();
  const gainNode = audioContext.createGain();

  oscillator.type = 'sine';
  oscillator.frequency.setValueAtTime(440, audioContext.currentTime); // 440 Hz - A4 note

  gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
  gainNode.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + 0.2);

  oscillator.connect(gainNode);
  gainNode.connect(audioContext.destination);

  oscillator.start();
  oscillator.stop(audioContext.currentTime + 0.2);
}

function playNostalgicMusic() {
  const audio = new Audio('https://example.com/nostalgic-music.mp3');
  audio.volume = 0.2; // Set volume to 20%
  audio.loop = true; // Loop the music
  audio.play().catch(error => console.error('Error playing audio:', error));
  return audio;
}

export default function MoodReader() {
  const [selectedEmotion, setSelectedEmotion] = useState('')
  const [moodHistory, setMoodHistory] = useState([])
  const [personalizedRecommendations, setPersonalizedRecommendations] = useState([])
  const [userName, setUserName] = useState('')
  const [inputRef, setInputRef] = useState(null);
  const [musicPlayer, setMusicPlayer] = useState(null);

  useEffect(() => {
    if (selectedEmotion) {
      setMoodHistory(prev => [...prev, { date: new Date().toLocaleDateString(), emotion: selectedEmotion }])
      updatePersonalizedRecommendations(selectedEmotion)
    }
  }, [selectedEmotion])

  useEffect(() => {
    return () => {
      if (musicPlayer) {
        musicPlayer.pause();
        musicPlayer.src = '';
      }
    };
  }, [musicPlayer]);

  useEffect(() => {
    if (inputRef) {
      const handleKeyPress = () => playTypingSound();
      inputRef.addEventListener('keydown', handleKeyPress);
      return () => {
        inputRef.removeEventListener('keydown', handleKeyPress);
      };
    }
  }, [inputRef]);

  const updatePersonalizedRecommendations = (emotion) => {
    const bookRecommendations = books[emotion]
    const movieRecommendations = movies[emotion]
    setPersonalizedRecommendations({ books: bookRecommendations, movies: movieRecommendations })
  }

  return (
    <div className="container mx-auto p-4 space-y-8 max-w-2xl">
      <h1 className="text-3xl font-bold text-center mb-8">Mood Reader</h1>

      {!userName ? (
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Welcome to Mood Reader</CardTitle>
            <CardDescription>Please enter your name to get started.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={(e) => {
              e.preventDefault();
              setUserName(e.target.name.value);
              const player = playNostalgicMusic();
              setMusicPlayer(player);
            }}>
              <div className="flex space-x-2">
                <Input
                  name="name"
                  placeholder="Your name"
                  required
                  ref={setInputRef}
                />
                <Button type="submit">Start</Button>
              </div>
            </form>
          </CardContent>
        </Card>
      ) : (
        <>
          <p className="text-center text-xl mb-8">Hello, {userName}! How are you feeling today?</p>

          {/* Emotion Selector */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Select your mood</CardTitle>
            </CardHeader>
            <CardContent>
              <RadioGroup onValueChange={setSelectedEmotion} className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4">
                {emotions.map(emotion => (
                  <div key={emotion} className="flex items-center space-x-2">
                    <RadioGroupItem value={emotion} id={emotion} />
                    <Label htmlFor={emotion}>{emotion}</Label>
                  </div>
                ))}
              </RadioGroup>
            </CardContent>
          </Card>

          {/* Book Recommendations */}
          {selectedEmotion && (
            <Card>
              <CardHeader>
                <CardTitle>Book Recommendations for {selectedEmotion} Mood</CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[400px]">
                  {books[selectedEmotion].map(book => (
                    <Card key={book.id} className="mb-4">
                      <CardHeader>
                        <CardTitle>{book.title}</CardTitle>
                        <CardDescription>{book.author}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <p>{book.description}</p>
                      </CardContent>
                      <CardFooter className="flex justify-between">
                        <div className="flex items-center">
                          <Star className="w-4 h-4 fill-yellow-400 mr-1" />
                          <span>{book.rating.toFixed(1)}</span>
                        </div>
                        <Button variant="outline" size="sm">
                          <ThumbsUp className="w-4 h-4 mr-2" />
                          Like
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </ScrollArea>
              </CardContent>
            </Card>
          )}

          {/* Mood Tracker */}
          <Card>
            <CardHeader>
              <CardTitle>Mood Tracker</CardTitle>
              <CardDescription>Track your emotions over time</CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[200px]">
                {moodHistory.map((entry, index) => (
                  <div key={index} className="flex items-center space-x-2 mb-2">
                    <Calendar className="w-4 h-4" />
                    <span>{entry.date}: {entry.emotion}</span>
                  </div>
                ))}
              </ScrollArea>
            </CardContent>
          </Card>

          {/* Personalized Recommendations */}
          {personalizedRecommendations.books && personalizedRecommendations.movies && (
            <Card>
              <CardHeader>
                <CardTitle>Personalized Recommendations</CardTitle>
                <CardDescription>Based on your mood history</CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[400px]">
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-semibold mb-2">Books</h3>
                      {personalizedRecommendations.books.map(book => (
                        <div key={book.id} className="mb-2">
                          <h4 className="font-semibold">{book.title}</h4>
                          <p className="text-sm text-gray-600">{book.author}</p>
                        </div>
                      ))}
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold mb-2">Movies</h3>
                      {personalizedRecommendations.movies.map(movie => (
                        <div key={movie.id} className="mb-2">
                          <h4 className="font-semibold">{movie.title}</h4>
                          <p className="text-sm text-gray-600">{movie.director}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          )}
        </>
      )}
    </div>
  )
}