'use client'

import { useState, useEffect } from 'react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Star, ThumbsUp, Calendar } from "lucide-react"
import { Input } from "@/components/ui/input"

const emotions = [
  'Happy', 'Sad', 'Anxious', 'Inspired', 'Angry', 'Calm', 'Excited', 'Frustrated',
  'Nostalgic', 'Curious', 'Overwhelmed', 'Hopeful', 'Bored', 'Confident', 'Confused',
  'Grateful', 'Lonely', 'Motivated', 'Relaxed', 'Stressed'
]

const books = {
  Happy: [
    { id: 1, title: "The Hitchhiker's Guide to the Galaxy", author: "Douglas Adams", description: "A comedic science fiction series that's sure to lift your spirits.", rating: 4.5 },
    { id: 2, title: "Good Omens", author: "Terry Pratchett & Neil Gaiman", description: "A hilarious take on the Apocalypse that will leave you in stitches.", rating: 4.3 },
    { id: 3, title: "The Rosie Project", author: "Graeme Simsion", description: "A charming and hilarious journey of love and self-discovery.", rating: 4.0 },
    { id: 4, title: "Bridget Jones's Diary", author: "Helen Fielding", description: "A witty and relatable story of a woman navigating life and love.", rating: 4.1 },
    { id: 5, title: "The Princess Bride", author: "William Goldman", description: "A fantastical adventure filled with humor, romance, and unforgettable characters.", rating: 4.7 },
    { id: 6, title: "The Martian", author: "Andy Weir", description: "A hilarious and thrilling tale of survival on Mars.", rating: 4.6 },
    { id: 7, title: "Where'd You Go, Bernadette", author: "Maria Semple", description: "A quirky and uplifting story about a mother-daughter relationship.", rating: 4.0 },
    { id: 8, title: "The Guernsey Literary and Potato Peel Pie Society", author: "Mary Ann Shaffer", description: "A charming historical novel filled with humor and warmth.", rating: 4.4 },
  ],
  Sad: [
    { id: 6, title: "The Fault in Our Stars", author: "John Green", description: "A touching story about love and loss that resonates with melancholy.", rating: 4.2 },
    { id: 7, title: "A Little Life", author: "Hanya Yanagihara", description: "An emotional journey through friendship and trauma.", rating: 4.1 },
    { id: 8, title: "The Road", author: "Cormac McCarthy", description: "A post-apocalyptic tale of a father and son's journey through a desolate America.", rating: 4.3 },
    { id: 9, title: "Never Let Me Go", author: "Kazuo Ishiguro", description: "A haunting and melancholic exploration of what it means to be human.", rating: 4.0 },
    { id: 10, title: "The Book Thief", author: "Markus Zusak", description: "A poignant story set in Nazi Germany, narrated by Death itself.", rating: 4.6 },
    { id: 11, title: "One Day", author: "David Nicholls", description: "A bittersweet love story spanning two decades.", rating: 3.9 },
    { id: 12, title: "The Kite Runner", author: "Khaled Hosseini", description: "A powerful tale of friendship, betrayal, and redemption.", rating: 4.3 },
    { id: 13, title: "The Lovely Bones", author: "Alice Sebold", description: "A haunting story of loss and healing told from the afterlife.", rating: 3.8 },
  ],
  Anxious: [
    { id: 11, title: "The Anxiety Toolkit", author: "Alice Boyes", description: "Practical strategies for managing anxiety and worry.", rating: 4.0 },
    { id: 12, title: "Hope and Help for Your Nerves", author: "Claire Weekes", description: "A classic self-help book for understanding and overcoming anxiety.", rating: 4.4 },
    { id: 13, title: "First, We Make the Beast Beautiful", author: "Sarah Wilson", description: "A new story about anxiety that's part memoir, part self-help guide.", rating: 4.2 },
    { id: 14, title: "The Worry Trick", author: "David A. Carbonell", description: "How your brain tricks you into expecting the worst and what you can do about it.", rating: 4.3 },
    { id: 15, title: "Dare", author: "Barry McDonagh", description: "A new way to end anxiety and stop panic attacks fast.", rating: 4.5 },
    { id: 16, title: "The Happiness Trap", author: "Russ Harris", description: "A guide to reducing stress and overcoming anxiety using ACT.", rating: 4.3 },
    { id: 17, title: "The Highly Sensitive Person", author: "Elaine N. Aron", description: "How to thrive when the world overwhelms you.", rating: 4.1 },
    { id: 18, title: "Quiet: The Power of Introverts in a World That Can't Stop Talking", author: "Susan Cain", description: "Exploring the strengths of introverts in a noisy world.", rating: 4.5 },
  ],
  Inspired: [
    { id: 16, title: "The Alchemist", author: "Paulo Coelho", description: "A philosophical novel about following your dreams.", rating: 4.6 },
    { id: 17, title: "Atomic Habits", author: "James Clear", description: "A guide to building good habits and breaking bad ones.", rating: 4.8 },
    { id: 18, title: "Big Magic", author: "Elizabeth Gilbert", description: "Creative living beyond fear and embracing curiosity.", rating: 4.4 },
    { id: 19, title: "The Artist's Way", author: "Julia Cameron", description: "A course in discovering and recovering your creative self.", rating: 4.5 },
    { id: 20, title: "Daring Greatly", author: "Brené Brown", description: "How the courage to be vulnerable transforms the way we live, love, parent, and lead.", rating: 4.7 },
    { id: 21, title: "The War of Art", author: "Steven Pressfield", description: "Break through blocks and win your inner creative battles.", rating: 4.3 },
    { id: 22, title: "Grit: The Power of Passion and Perseverance", author: "Angela Duckworth", description: "Why passion and persistence are more important than talent.", rating: 4.5 },
    { id: 23, title: "The Last Lecture", author: "Randy Pausch", description: "A professor's final lecture on achieving your childhood dreams.", rating: 4.6 },
  ],
  Angry: [
    { id: 21, title: "The Subtle Art of Not Giving a F*ck", author: "Mark Manson", description: "A counterintuitive approach to living a good life.", rating: 4.2 },
    { id: 22, title: "Rage Becomes Her", author: "Soraya Chemaly", description: "An exploration of the power of female anger.", rating: 4.5 },
    { id: 23, title: "The Dance of Anger", author: "Harriet Lerner", description: "A woman's guide to changing the patterns of intimate relationships.", rating: 4.3 },
    { id: 24, title: "Anger: Wisdom for Cooling the Flames", author: "Thich Nhat Hanh", description: "Buddhist wisdom for transforming anger into peace and healing.", rating: 4.6 },
    { id: 25, title: "The Cow in the Parking Lot", author: "Leonard Scheff & Susan Edmiston", description: "A Zen approach to overcoming anger.", rating: 4.1 },
    { id: 26, title: "The Upside of Your Dark Side", author: "Todd Kashdan & Robert Biswas-Diener", description: "Why being your whole self - not just your 'good' self - drives success and fulfillment.", rating: 4.2 },
    { id: 27, title: "The Gift of Anger", author: "Arun Gandhi", description: "And other lessons from my grandfather Mahatma Gandhi.", rating: 4.4 },
    { id: 28, title: "Anger Management Workbook for Men", author: "Aaron Karmin", description: "Take control of your anger and master your emotions.", rating: 4.3 },
  ],
}

// Add placeholder books for emotions without specific recommendations
emotions.forEach(emotion => {
  if (!books[emotion]) {
    books[emotion] = [
      { id: 1000 + emotions.indexOf(emotion) * 5, title: "Embracing " + emotion, author: "Jane Doe", description: "A comprehensive guide to understanding and navigating " + emotion.toLowerCase() + " emotions.", rating: 4.2 },
      { id: 1001 + emotions.indexOf(emotion) * 5, title: "The " + emotion + " Chronicles", author: "John Smith", description: "An engaging novel that captures the essence of feeling " + emotion.toLowerCase() + ".", rating: 4.0 },
      { id: 1002 + emotions.indexOf(emotion) * 5, title: emotion + " Mindset", author: "Alex Johnson", description: "Practical strategies for harnessing the power of " + emotion.toLowerCase() + " emotions.", rating: 4.3 },
      { id: 1003 + emotions.indexOf(emotion) * 5, title: "The Art of Being " + emotion, author: "Sam Brown", description: "A philosophical exploration of " + emotion.toLowerCase() + " and its role in our lives.", rating: 4.1 },
      { id: 1004 + emotions.indexOf(emotion) * 5, title: emotion + " in the Modern World", author: "Taylor Green", description: "An insightful analysis of how " + emotion.toLowerCase() + " shapes our society and personal experiences.", rating: 4.4 },
    ]
  }
})

function playTypingSound() {
  const audioContext = new (window.AudioContext || window.webkitAudioContext)();
  const oscillator = audioContext.createOscillator();
  const gainNode = audioContext.createGain();

  oscillator.type = 'sine';
  oscillator.frequency.setValueAtTime(440, audioContext.currentTime); // 440 Hz - A4 note

  gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
  gainNode.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + 0.2);

  oscillator.connect(gainNode);
  gainNode.connect(audioContext.destination);

  oscillator.start();
  oscillator.stop(audioContext.currentTime + 0.2);
}

export default function MoodReader() {
  const [selectedEmotion, setSelectedEmotion] = useState('')
  const [moodHistory, setMoodHistory] = useState([])
  const [personalizedRecommendations, setPersonalizedRecommendations] = useState([])
  const [userName, setUserName] = useState('')
  const [inputRef, setInputRef] = useState(null);

  useEffect(() => {
    if (selectedEmotion) {
      setMoodHistory(prev => [...prev, { date: new Date().toLocaleDateString(), emotion: selectedEmotion }])
      updatePersonalizedRecommendations(selectedEmotion)
    }
  }, [selectedEmotion])

  useEffect(() => {
    if (inputRef) {
      const handleKeyPress = () => playTypingSound();
      inputRef.addEventListener('keydown', handleKeyPress);
      return () => {
        inputRef.removeEventListener('keydown', handleKeyPress);
      };
    }
  }, [inputRef]);

  const updatePersonalizedRecommendations = (emotion) => {
    // In a real app, this would use more sophisticated logic based on user history
    const recommendations = books[emotion]
    setPersonalizedRecommendations(recommendations)
  }

  return (
    <div className="container mx-auto p-4 space-y-8 max-w-2xl">
      <h1 className="text-3xl font-bold text-center mb-8">Mood Reader</h1>

      {!userName ? (
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Welcome to Mood Reader</CardTitle>
            <CardDescription>Please enter your name to get started.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={(e) => { e.preventDefault(); setUserName(e.target.name.value); }}>
              <div className="flex space-x-2">
                <Input
                  name="name"
                  placeholder="Your name"
                  required
                  ref={setInputRef}
                />
                <Button type="submit">Start</Button>
              </div>
            </form>
          </CardContent>
        </Card>
      ) : (
        <>
          <p className="text-center text-xl mb-8">Hello, {userName}! How are you feeling today?</p>

          {/* Emotion Selector */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Select your mood</CardTitle>
            </CardHeader>
            <CardContent>
              <RadioGroup onValueChange={setSelectedEmotion} className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4">
                {emotions.map(emotion => (
                  <div key={emotion} className="flex items-center space-x-2">
                    <RadioGroupItem value={emotion} id={emotion} />
                    <Label htmlFor={emotion}>{emotion}</Label>
                  </div>
                ))}
              </RadioGroup>
            </CardContent>
          </Card>

          {/* Book Recommendations */}
          {selectedEmotion && (
            <Card>
              <CardHeader>
                <CardTitle>Book Recommendations for {selectedEmotion} Mood</CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[400px]">
                  {books[selectedEmotion].map(book => (
                    <Card key={book.id} className="mb-4">
                      <CardHeader>
                        <CardTitle>{book.title}</CardTitle>
                        <CardDescription>{book.author}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <p>{book.description}</p>
                      </CardContent>
                      <CardFooter className="flex justify-between">
                        <div className="flex items-center">
                          <Star className="w-4 h-4 fill-yellow-400 mr-1" />
                          <span>{book.rating.toFixed(1)}</span>
                        </div>
                        <Button variant="outline" size="sm">
                          <ThumbsUp className="w-4 h-4 mr-2" />
                          Like
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </ScrollArea>
              </CardContent>
            </Card>
          )}

          {/* Mood Tracker */}
          <Card>
            <CardHeader>
              <CardTitle>Mood Tracker</CardTitle>
              <CardDescription>Track your emotions over time</CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[200px]">
                {moodHistory.map((entry, index) => (
                  <div key={index} className="flex items-center space-x-2 mb-2">
                    <Calendar className="w-4 h-4" />
                    <span>{entry.date}: {entry.emotion}</span>
                  </div>
                ))}
              </ScrollArea>
            </CardContent>
          </Card>

          {/* Personalized Recommendations */}
          {personalizedRecommendations.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Personalized Recommendations</CardTitle>
                <CardDescription>Based on your mood history</CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[200px]">
                  {personalizedRecommendations.map(book => (
                    <div key={book.id} className="mb-2">
                      <h3 className="font-semibold">{book.title}</h3>
                      <p className="text-sm text-gray-600">{book.author}</p>
                    </div>
                  ))}
                </ScrollArea>
              </CardContent>
            </Card>
          )}
        </>
      )}
    </div>
  )
}